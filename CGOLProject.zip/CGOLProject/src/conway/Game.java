package conway;

public class Game extends Thread {
	
	private int r, c;
	private int[][] arr ;
	private int[][] NextLife = new int[100][100];

	public Game(int r, int c, int[][] arr) {
		this.r=r;
		this.c=c;
		this.arr = arr;
	}
	
	public void run() {
		
		//Calculating the time elapsed so far.
		
		long startTime = System.nanoTime();
		int i,j,k,l;

		// Loop through every cell of the every row and column
		
		for(i=1; i<r-1; i++){
			for(j=1; j<c-1; j++){

				// Finding how many cells are alive
				
				int OneCell = 0;
				for(k=-1; k<=1; k++)
					for(l=-1; l<=1; l++)
						OneCell = OneCell + arr[i+k][j+l];

				OneCell = OneCell - arr[i][j];

				// If cell is lonely then it dies
				if((arr[i][j] == 1) && (OneCell < 2)){
					NextLife[i][j] = 0;
				}

				// If cell is over populated it dies
				
				else if((arr[i][j] == 1) && (OneCell > 3)){
					NextLife[i][j] = 0;
				}

				// A new cell is born as 3 adjacent cells are alive
				else if((arr[i][j] == 0) && (OneCell ==3)){
					NextLife[i][j] = 1;
				}

				// Nothing happens so it remains same
				else{
					NextLife[i][j] = arr[i][j];
				}
			}
		}

		System.out.println();
		System.out.println("Next Life is:");

		// Printing the next life
		for(k=0; k<r; k++){
			for(l=0; l<c; l++){
				System.out.print(NextLife[k][l] + " ");
			}
			System.out.println();
		}
		
		//Assigning the next life to the main array to print further generation
		
		for (k = 0; k < r; k++) {
			for (l = 0; l < c; l++) {
				arr[k][l] = NextLife[k][l];
			}
		}
		//Calculating the time to execute the next generation of CGOL
		
		long time = System.nanoTime() - startTime;
        System.out.println("Execution time taken for Different Generations's: " + time + " ns");
        
        System.out.println("Input Y for continuing the game and any other character to end the game: ");
	}

}

